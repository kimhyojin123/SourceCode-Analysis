package pt.technic.apps.minesfinder;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class GlobalRankWindow extends JFrame{
	private final int EASY = LevelAndCommand.EASY.ordinal();
	private final int HARD = LevelAndCommand.HARD.ordinal();
    private RecordTable globalRecords[][];
    private RecordsLabel recordsLabel[];
    private JLabel panelTitle;
    private JButton okBtn;
    private JButton localBtn;
    
    public GlobalRankWindow(RecordsLabel[] recordsLabel) {
        globalRecords = RecordController.getInstance().getGlobalRecords();
        this.recordsLabel = recordsLabel;
    	initComponent();
    	okBtn.addActionListener(evt -> this.setVisible(false));
    	localBtn.addActionListener(evt -> showLocalRank());
    	pack();
    }
    private void initComponent() {
		setTitle("Global");
		okBtn = new JButton("ok");
		localBtn = new JButton("내 점수");
		panelTitle = new JLabel();
		panelTitle.setBackground(Color.LIGHT_GRAY);
		panelTitle.setFont(Constants.UBUNTU_FONT); // NOI18N
		panelTitle.setHorizontalAlignment(SwingConstants.CENTER);
		panelTitle.setText(Constants.MINES_FINDER_TEXT.getRecordsText());
		panelTitle.setOpaque(true);
		JPanel globalRankPane = new JPanel();
		globalRankPane.setLayout(new GridLayout(1, 0));
		for(int i = EASY; i <= HARD; i++) {
			globalRankPane.add(recordsLabel[i].text);
			JPanel levelPanel = new JPanel();
			levelPanel.setLayout(new GridLayout(3, 0));
			for(int j = EASY; j <= HARD; j++) {
				levelPanel.add(new JLabel(String.valueOf(j + 1)));
				levelPanel.add(new JLabel(globalRecords[i][j].getName()));
				levelPanel.add(new JLabel(String.valueOf(globalRecords[i][j].getScore() / 1000)));
			}
			globalRankPane.add(levelPanel);
		}
		JPanel btnPanel = new JPanel();
		btnPanel.setLayout(new GridLayout(0,2));
		btnPanel.add(localBtn);
		btnPanel.add(okBtn);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(panelTitle, BorderLayout.PAGE_START);
		getContentPane().add(globalRankPane, BorderLayout.CENTER);
		getContentPane().add(btnPanel, BorderLayout.SOUTH);
    }
    private void showLocalRank() {
    	LocalRankWindow localRankWindow = new LocalRankWindow();
    	localRankWindow.setVisible(true);
    	this.setVisible(false);
    }
}
