package text;

public class EnglishCustomSettingWindowText extends CustomSettingWindowText{
	{
		 setCustomSettingTitle("Game Setting");
		 setWidthText("Width");
		 setHeightText("Height");
		 setNumMinesText("Mines");
		 setSubmitText("Submit");
		 setMuchNumMinesWarningMessageContent("Mines are too much!!");
		 setZeroNumMinesWarningMessageContent("Enter number of mines!!");
	}
}
