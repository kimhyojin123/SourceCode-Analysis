package text;

public class KoreanMinesFinderText extends MinesFinderText {
	{
		 setMainTitle("지뢰찾기");
		 setRecordsText("기록");
		 String[] levelText = {"쉬움", "노멀", "어려움", "나가기"};
		 setLevelText(levelText);
		 String[] menuBarText = {"옵션", "게임 설명"};
		 setMenuBarText(menuBarText);
		 String[] optionMenuText = {"언어", "랭킹", "셋팅", "로그아웃"};
		 setOptionMenuText(optionMenuText);
		 setWarningMessageTitle("경고");
	}
}
