package text;

public class SignWindowText {
	public static SignWindowText[] subObj = { new EnglishSignWindowText(), new KoreanSignWindowText() };
	// UItext for SignWindow
	private String signWindowTitle;
	private String nameText;
	private String passwordText;
	private String signInText;
	private String signUpText;
	private String signInSuccessMessageContent;
	private String signInFailedMessageContent;
	private String signInFailedMessageTitle;
	private String signUpSuccessMessageContent;
	private String signUpFailedMessageContent;
	private String signUpFailedMessageTitle;
	private String checkHasSpaceMessageContent;
	
	public String getSignWindowTitle() {
		return signWindowTitle;
	}
	public String getNameText() {
		return nameText;
	}
	public String getPasswordText() {
		return passwordText;
	}
	public String getSignInText() {
		return signInText;
	}
	public String getSignUpText() {
		return signUpText;
	}
	public String getSignInSuccessMessageContent() {
		return signInSuccessMessageContent;
	}
	public String getSignInFailedMessageContent() {
		return signInFailedMessageContent;
	}
	public String getSignInFailedMessageTitle() {
		return signInFailedMessageTitle;
	}
	public String getSignUpSuccessMessageContent() {
		return signUpSuccessMessageContent;
	}
	public String getSignUpFailedMessageContent() {
		return signUpFailedMessageContent;
	}
	public String getSignUpFailedMessageTitle() {
		return signUpFailedMessageTitle;
	}
	public String getCheckHasSpaceMessageContent() {
		return checkHasSpaceMessageContent;
	}
	protected void setSignWindowTitle(String signWindowTitle) {
		this.signWindowTitle = signWindowTitle;
	}
	protected void setNameText(String nameText) {
		this.nameText = nameText;
	}
	protected void setPasswordText(String passwordText) {
		this.passwordText = passwordText;
	}
	protected void setSignInText(String signInText) {
		this.signInText = signInText;
	}
	protected void setSignUpText(String signUpText) {
		this.signUpText = signUpText;
	}
	protected void setSignInSuccessMessageContent(String signInSuccessMessageContent) {
		this.signInSuccessMessageContent = signInSuccessMessageContent;
	}
	protected void setSignInFailedMessageContent(String signInFailedMessageContent) {
		this.signInFailedMessageContent = signInFailedMessageContent;
	}
	protected void setSignInFailedMessageTitle(String signInFailedMessageTitle) {
		this.signInFailedMessageTitle = signInFailedMessageTitle;
	}
	protected void setSignUpSuccessMessageContent(String signUpSuccessMessageContent) {
		this.signUpSuccessMessageContent = signUpSuccessMessageContent;
	}
	protected void setSignUpFailedMessageContent(String signUpFailedMessageContent) {
		this.signUpFailedMessageContent = signUpFailedMessageContent;
	}
	protected void setSignUpFailedMessageTitle(String signUpFailedMessageTitle) {
		this.signUpFailedMessageTitle = signUpFailedMessageTitle;
	}
	protected void setCheckHasSpaceMessageContent(String checkHasSpaceMessageContent) {
		this.checkHasSpaceMessageContent = checkHasSpaceMessageContent;
	}
}
