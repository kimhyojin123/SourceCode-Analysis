package pt.technic.apps.minesfinder;

public enum LevelAndCommand {
	EASY, MEDIUM, HARD, EXIT, RANK, LANGUAGE, SETTING, SIGNOUT;
}
