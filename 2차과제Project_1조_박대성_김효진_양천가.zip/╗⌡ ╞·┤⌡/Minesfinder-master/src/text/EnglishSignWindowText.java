package text;

public class EnglishSignWindowText extends SignWindowText {
	{
		 setSignWindowTitle("Sign In&Up");
		 setNameText("Name");
		 setPasswordText("Password");
		 setSignInText("SignIn");
		 setSignUpText("SignUp");
		 setSignInSuccessMessageContent("Signin success!");
		 setSignInFailedMessageContent("Check your name or pw");
		 setSignInFailedMessageTitle("Signin failed");
		 setSignUpSuccessMessageContent("Signup success!");
		 setSignUpFailedMessageContent("Already exist name");
		 setSignUpFailedMessageTitle("Signup failed");
		 setCheckHasSpaceMessageContent("Please input name or password");
	}
}
