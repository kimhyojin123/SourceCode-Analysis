package pt.technic.apps.minesfinder;

public enum Language {
	ENGLISH, KOREAN, CHINESE, ;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		switch(this) {
		case ENGLISH:
			return "English";
		case KOREAN:
			return "한글";
		case CHINESE:
			return "中国語";
			default:
				return null;
		}
	}
	public static Language toLanguage(String language) {
		if(language.equals(ENGLISH.toString())) {
			return ENGLISH;
		}else if(language.equals(KOREAN.toString())) {
			return KOREAN;
		}else if(language.equals(CHINESE.toString())) {
			return CHINESE;
		}else
			return null;
	}
}
