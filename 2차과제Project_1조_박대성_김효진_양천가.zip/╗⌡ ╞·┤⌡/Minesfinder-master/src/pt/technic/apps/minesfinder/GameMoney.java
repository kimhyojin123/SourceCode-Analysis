package pt.technic.apps.minesfinder;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GameMoney implements Serializable {
	private int gameMoney;
	
	public GameMoney() {
		gameMoney=10;
	}
	public GameMoney(int gameMoney) {
		this.gameMoney = gameMoney;
	}
	public int increaseMoney() {
		return ++gameMoney;
	}
	public int decreaseMoney() {
		return --gameMoney;
	}
	public int getMoney() {
		return gameMoney;
	}
	
}
