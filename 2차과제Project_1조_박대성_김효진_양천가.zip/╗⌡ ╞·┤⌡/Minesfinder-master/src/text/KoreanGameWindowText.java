package text;

public class KoreanGameWindowText extends GameWindowText {
	{
		 setGameTitle("게임");
		 setResetText("리셋");
		 setLostMessageContent("지뢰를 밟아버렸네");
		 setLostMessageTitle("졌어");
		 setVictoryMessageContent("축하합니다. 당신의 기록은 ");
		 setVictoryMessageTitle("승리!");
		
		 setSecond(" 초");
		 setRestMinesText("남은 지뢰 : ");
	}
}
