package text;

public class GameWindowText {
	public static GameWindowText[] subObj = { new EnglishGameWindowText(), new KoreanGameWindowText()};
	private String gameTitle;
	private String lostMessageContent;
	private String lostMessageTitle;
	private String victoryMessageContent;
	private String victoryMessageTitle;
	private String resetText;
	private String second;
	private String restMinesText;
	public String getLostMessageContent() {
		return lostMessageContent;
	}
	public String getLostMessageTitle() {
		return lostMessageTitle;
	}
	public String getVictoryMessageContent() {
		return victoryMessageContent;
	}
	public String getVictoryMessageTitle() {
		return victoryMessageTitle;
	}
	public String getResetText() {
		return resetText;
	}
	public String getSecond() {
		return second;
	}
	public String getRestMinesText() {
		return restMinesText;
	}
	protected void setLostMessageContent(String lostMessageContent) {
		this.lostMessageContent = lostMessageContent;
	}
	protected void setLostMessageTitle(String lostMessageTitle) {
		this.lostMessageTitle = lostMessageTitle;
	}
	protected void setVictoryMessageContent(String victoryMessageContent) {
		this.victoryMessageContent = victoryMessageContent;
	}
	protected void setVictoryMessageTitle(String victoryMessageTitle) {
		this.victoryMessageTitle = victoryMessageTitle;
	}
	protected void setResetText(String resetText) {
		this.resetText = resetText;
	}
	protected void setSecond(String second) {
		this.second = second;
	}
	protected void setRestMinesText(String restMinesText) {
		this.restMinesText = restMinesText;
	}
	protected void setGameTitle(String gameTitle) {
		this.gameTitle = gameTitle;
	}
	public String getGameTitle() {
		return gameTitle;
	}
}
