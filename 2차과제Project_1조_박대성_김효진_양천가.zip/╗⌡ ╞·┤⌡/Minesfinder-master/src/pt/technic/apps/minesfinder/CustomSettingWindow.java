package pt.technic.apps.minesfinder;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

public class CustomSettingWindow extends JFrame {
	private JLabel title;
	private JTextField inputWidth;
	private JTextField inputHeight;
	private JTextField inputNumMines;
	private JLabel widthLabel;
	private JLabel heightLabel;
	private JLabel numMinesLabel;
	private JPanel inputSettingPane;
	private JButton submitSetting;
	public CustomSettingWindow() {
		initComponent();

	}
	private void initComponent() {
		setTitle(Constants.CUSTOM_SETTING_WINDOW_TEXT.getCustomSettingTitle());
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setCursor(Constants.DEFAULT_CURSOR);
		setResizable(false);
        title = new JLabel(Constants.CUSTOM_SETTING_WINDOW_TEXT.getCustomSettingTitle());
        title.setBackground(Color.LIGHT_GRAY); 
        title.setFont(Constants.UBUNTU_FONT); // NOI18N
        title.setHorizontalAlignment(SwingConstants.CENTER);
		
        inputWidth = new JTextField();
		inputHeight = new JTextField();
		inputNumMines = new JTextField();
		widthLabel = new JLabel(Constants.CUSTOM_SETTING_WINDOW_TEXT.getWidthText());
		heightLabel = new JLabel(Constants.CUSTOM_SETTING_WINDOW_TEXT.getHeightText());
		numMinesLabel = new JLabel(Constants.CUSTOM_SETTING_WINDOW_TEXT.getNumMinesText());
        submitSetting = new JButton(Constants.CUSTOM_SETTING_WINDOW_TEXT.getSubmitText());
		inputSettingPane = new JPanel();
		
        inputSettingPane.setLayout(new GridLayout(0, 2));
		inputSettingPane.add(widthLabel);
		inputSettingPane.add(inputWidth);
		inputSettingPane.add(heightLabel);
		inputSettingPane.add(inputHeight);
		inputSettingPane.add(numMinesLabel);
		inputSettingPane.add(inputNumMines);
		submitSetting.setHorizontalAlignment(SwingConstants.CENTER);
		submitSetting.addActionListener(
				evt -> { 
					try {
						int width = Integer.parseInt(inputWidth.getText());
						int height = Integer.parseInt(inputHeight.getText());
						int numMines = Integer.parseInt(inputNumMines.getText());
						if(width * height > numMines) {
							new GameWindow(new Minefield(width, height, numMines), new RecordTable()).setVisible(true);
							this.setVisible(false);
						}else {
	                        JOptionPane.showMessageDialog(null, Constants.CUSTOM_SETTING_WINDOW_TEXT.getMuchNumMinesWarningMessageContent(), Constants.MINES_FINDER_TEXT.getWarningMessageTitle(), JOptionPane.WARNING_MESSAGE);
						}
					}catch(NumberFormatException nfe) {
                        JOptionPane.showMessageDialog(null, Constants.CUSTOM_SETTING_WINDOW_TEXT.getZeroNumMinesWarningMessageContent(),
                        		Constants.MINES_FINDER_TEXT.getWarningMessageTitle(), JOptionPane.WARNING_MESSAGE);
                        inputWidth.setText("");
                        inputHeight.setText("");
                        inputNumMines.setText("");
					}
		});
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(title, BorderLayout.NORTH);
		getContentPane().add(inputSettingPane, BorderLayout.CENTER);
		getContentPane().add(submitSetting, BorderLayout.SOUTH);
		setVisible(true);
		pack();
	}
}
