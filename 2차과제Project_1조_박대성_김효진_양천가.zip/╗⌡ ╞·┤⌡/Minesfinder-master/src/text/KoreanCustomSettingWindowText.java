package text;

public class KoreanCustomSettingWindowText extends CustomSettingWindowText{
	{
		 setCustomSettingTitle("사용자 설정");
		 setWidthText("가로");
		 setHeightText("세로");
		 setNumMinesText("지뢰 수");
		 setSubmitText("입력");
		 setMuchNumMinesWarningMessageContent("지뢰 개수가 너무 많아!");
		 setZeroNumMinesWarningMessageContent("숫자를 입력해주세요");
	}
}
