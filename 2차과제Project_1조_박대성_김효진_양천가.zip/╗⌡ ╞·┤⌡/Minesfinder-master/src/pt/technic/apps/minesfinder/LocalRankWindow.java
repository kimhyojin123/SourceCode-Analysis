package pt.technic.apps.minesfinder;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.LayoutStyle;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

public class LocalRankWindow extends JFrame {
	private static final int EASY = LevelAndCommand.EASY.ordinal(); // 0
	private static final int MEDIUM = LevelAndCommand.MEDIUM.ordinal(); // 1
	private static final int HARD = LevelAndCommand.HARD.ordinal(); // 2

	private RecordTable localRecords[]; // 기록점수 저장해놓는 객체 -- Tables for Record
	private RecordsLabel recordsLabel[]; // 텍스트 객체 -- Objects Label for record;
	private JPanel panelRecords;
	private JLabel panelTitle;
	private JButton okBtn;
	private JButton globalBtn;

	public LocalRankWindow() {
		initComponents();

		localRecords = RecordController.getInstance().getRecords();
		for (int i = EASY; i <= HARD; i++) {
			recordsLabel[i].name.setText(localRecords[i].getName());
			recordsLabel[i].points.setText(Long.toString(localRecords[i].getScore() / 1000));
		}

	}

	private void initComponents() {
		panelRecords = new JPanel();
		okBtn = new JButton("Ok");
		globalBtn = new JButton("글로벌 랭킹");

		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setTitle(Constants.MINES_FINDER_TEXT.getMainTitle());
		setCursor(Constants.DEFAULT_CURSOR);
		setPreferredSize(Constants.DEFAULT_DIMENSION);
		setResizable(false);
		
		globalBtn.addActionListener(evt -> showGlobalRank());
		okBtn.addActionListener(evt -> this.setVisible(false));
		initLabels();
		initLayout();
		initTitle();
		initLabels();
		panelRecords.setBackground(Color.WHITE);
		getContentPane().add(panelRecords, BorderLayout.CENTER);
		pack();
	}
	private void initLayout() {
		GroupLayout panelRecordsLayout = new GroupLayout(panelRecords);
		panelRecords.setLayout(panelRecordsLayout);
		panelRecordsLayout.setHorizontalGroup(panelRecordsLayout.createParallelGroup(GroupLayout.Alignment.CENTER)
				.addComponent(recordsLabel[EASY].text, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				.addGroup(panelRecordsLayout.createSequentialGroup().addContainerGap().addGroup(panelRecordsLayout
						.createParallelGroup(GroupLayout.Alignment.CENTER)
						.addGroup(panelRecordsLayout.createSequentialGroup().addComponent(recordsLabel[EASY].name)
								.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(recordsLabel[EASY].points))
						.addComponent(recordsLabel[MEDIUM].text, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addGroup(panelRecordsLayout.createSequentialGroup().addComponent(recordsLabel[MEDIUM].name)
								.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(recordsLabel[MEDIUM].points))
						.addComponent(recordsLabel[HARD].text, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addGroup(panelRecordsLayout.createSequentialGroup().addComponent(recordsLabel[HARD].name)
								.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(recordsLabel[HARD].points))
						.addGroup(panelRecordsLayout.createSequentialGroup().addComponent(globalBtn)
								.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(okBtn)))));
		panelRecordsLayout.setVerticalGroup(panelRecordsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				.addGroup(panelRecordsLayout.createSequentialGroup().addGap(18, 18, 18)
						.addComponent(recordsLabel[EASY].text).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
						.addGroup(panelRecordsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(recordsLabel[EASY].points).addComponent(recordsLabel[EASY].name))
						.addGap(18, 18, 18).addComponent(recordsLabel[MEDIUM].text)
						.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
						.addGroup(panelRecordsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(recordsLabel[MEDIUM].points).addComponent(recordsLabel[MEDIUM].name))
						.addGap(18, 18, 18).addComponent(recordsLabel[HARD].text)
						.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
						.addGroup(panelRecordsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(recordsLabel[HARD].points).addComponent(recordsLabel[HARD].name))
						.addGap(18, 18, 18)
						.addGroup(panelRecordsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(globalBtn).addComponent(okBtn))));
	}
	private void initTitle() {
		panelTitle = new JLabel();
		panelTitle.setBackground(Color.LIGHT_GRAY);
		new Action().setLabel(panelTitle, Constants.MINES_FINDER_TEXT.getRecordsText());
		getContentPane().add(panelTitle, BorderLayout.PAGE_START);
	}
	private void initLabels() {
		recordsLabel = new RecordsLabel[3];
		for (int i = EASY; i <= HARD; i++) {
			recordsLabel[i] = new RecordsLabel();
			recordsLabel[i].text = new JLabel();
			recordsLabel[i].name = new JLabel();
			recordsLabel[i].points = new JLabel();
		}
		for (int i = EASY; i <= HARD; i++) {
			recordsLabel[i].text.setFont(Constants.NOTO_SANS_FONT); // NOI18N
			recordsLabel[i].text.setHorizontalAlignment(SwingConstants.CENTER);
			recordsLabel[i].text.setText(Constants.MINES_FINDER_TEXT.getLevelText()[i]);
			recordsLabel[i].name.setText(Constants.RESET_PLAYERNAME);
			recordsLabel[i].points.setText(Constants.RESET_PLAYCOUNT);
		}
	}
	private void showGlobalRank() {
		GlobalRankWindow globalRankWindow = new GlobalRankWindow(recordsLabel);
		globalRankWindow.setVisible(true);
		this.setVisible(false);
	}
}
