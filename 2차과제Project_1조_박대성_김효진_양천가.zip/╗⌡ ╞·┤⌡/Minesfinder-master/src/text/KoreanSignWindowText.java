package text;

public class KoreanSignWindowText extends SignWindowText {
	{
		 setSignWindowTitle("로그인&회원가입");
		 setNameText("이름");
		 setPasswordText("비밀번호");
		 setSignInText("로그인");
		 setSignUpText("회원가입");
		 setSignInSuccessMessageContent("로그인 성공!");
		 setSignInFailedMessageContent("이름과 비밀번호를 확인해주세요");
		 setSignInFailedMessageTitle("로그인 실패");
		 setSignUpSuccessMessageContent("회원가입 성공!");
		 setSignUpFailedMessageContent("이미 같은 이름이 있습니다");
		 setSignUpFailedMessageTitle("회원가입 실패");
		 setCheckHasSpaceMessageContent("이름과 비밀번호를 입력하세요");
	}
}
