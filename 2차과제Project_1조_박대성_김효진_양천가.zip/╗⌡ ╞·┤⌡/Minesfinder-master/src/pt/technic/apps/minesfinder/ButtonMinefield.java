package pt.technic.apps.minesfinder;

import java.awt.Color;
import javax.swing.JButton;

/**
 *
 * @author Gabriel Massadas
 */
public class ButtonMinefield extends JButton {
    private int state, col, line;
    private boolean isHinted;

    public ButtonMinefield(int col, int line) {
        this.col = col;
        this.line = line;
        state=Minefield.COVERED;
        isHinted = false;
    }
   
    
    public void setState(int state) {
        this.state=state;
        switch (state) {
            case Minefield.EMPTY:
                setText("");
                setBackground(Color.gray);
                break;
            case Minefield.COVERED:
                setText("");
                setBackground(null);
                break;
            case Minefield.QUESTION:
                setText("?");
                setBackground(Color.yellow);
                break;
            case Minefield.MARKED:
                setText("!");
                setBackground(Color.red);
                break;
            case Minefield.BUSTED:
                setText("*");
                setBackground(Color.orange);
                break;
            case Minefield.UNREVEAL:
            	setBackground(Color.DARK_GRAY);
            	System.out.println(state);
            default:
                setText(String.valueOf(state));
                setBackground(Color.gray);
                break;
        }
        if(isHinted) {
        	setBackground(Color.green);
        }
    }

    public int getState() {
        return state;
    }

    public int getCol() {
        return col;
    }

    public int getLine() {
        return line;
    }


	public boolean isHinted() {
		return isHinted;
	}


	public void setHinted(boolean isHinted) {
		this.isHinted = isHinted;
	}
    
    
    
}
