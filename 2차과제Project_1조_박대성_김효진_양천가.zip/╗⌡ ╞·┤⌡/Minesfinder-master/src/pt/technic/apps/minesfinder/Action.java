package pt.technic.apps.minesfinder;

import java.awt.Font;
import java.awt.event.ActionEvent;

import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

public class Action {
	private static int restart = 1;
	public void btnLevelActionPerformed(ActionEvent evt, RecordTable record, Minefield minefield) {//GEN-FIRST:event_btnEasyActionPerformed
        GameWindow gameWindow = new GameWindow(minefield, record);
        gameWindow.setVisible(true);
    }//GEN-LAST:event_btnEasyActionPerformed

    public void btnExitActionPerformed(ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnExitActionPerformed

    public void showRankActionPerformed(ActionEvent evt) {
    	LocalRankWindow rankWindow = new LocalRankWindow();
    	rankWindow.setVisible(true);
    }
    public void setLanguageActionPerformed(ActionEvent evt) {
    	JMenuItem item = (JMenuItem) evt.getSource();
    	changeLanguage(item.getText());
    }
    public void setWindowActionPerformed(ActionEvent evt) {
    	CustomSettingWindow settingWindow = new CustomSettingWindow();
    }
    public void signOutActionPerformed(ActionEvent evt, JLabel userNameLabel) {
        SignWindow signWindow = new SignWindow(userNameLabel);
        signWindow.setVisible(true);
        signWindow.setAlwaysOnTop(true);
    }
    public void ExplanationActionPerformed(ActionEvent evt) {
    	JOptionPane.showMessageDialog(null, "At first, click anywhere and you can see numbers where you clicked. This number is the number that indicates how many land mines are around the button.\r\n" + 
				"By looking at the numbers, press the button while guessing which of the surrounding buttons will be planted.\r\n" + 
				"If you press the mine-planted button, the game will end, and if you press the rest of the button except the mine-planted button to the end, you will win the game.",
                "GameExplanation", JOptionPane.PLAIN_MESSAGE);
    }
    public void changeLanguage(String language) {
    	Constants.changeLanguage(language);
    }
	public void btnRestartActionPerformed(ActionEvent evt, RecordTable record, Minefield minefield) {
		minefield = new Minefield(minefield.getWidth(), minefield.getHeight(), minefield.getNumMines());
		btnLevelActionPerformed(evt, record, minefield);
	}    
	public void setLabel(JLabel label, Font font, String text) {
        label.setFont(font);
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setText(text);
        label.setOpaque(true);
    }
	public void setLabel(JLabel label, String text) {
		setLabel(label, Constants.UBUNTU_FONT, text);
	}
}
