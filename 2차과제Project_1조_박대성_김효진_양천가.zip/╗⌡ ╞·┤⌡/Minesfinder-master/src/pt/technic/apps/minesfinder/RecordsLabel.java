package pt.technic.apps.minesfinder;

import javax.swing.JLabel;

public class RecordsLabel {
	public JLabel text;
	public JLabel name;
	public JLabel points;
}
