package text;

public class EnglishMinesFinderText extends MinesFinderText {
	{
		 setMainTitle("MinesFinder");
		 setRecordsText("Records");
		 String[] levelText = {"Easy", "Medium", "Hard", "Exit"};
		 setLevelText(levelText);
		 String[] menuBarText = {"Option", "Game Explanation"};
		 setMenuBarText(menuBarText);
		 String[] optionMenuText = {"Language", "Rank", "Setting", "Sign Out"};
		 setOptionMenuText(optionMenuText);
		 
		 setWarningMessageTitle("Warning");

	}
}
