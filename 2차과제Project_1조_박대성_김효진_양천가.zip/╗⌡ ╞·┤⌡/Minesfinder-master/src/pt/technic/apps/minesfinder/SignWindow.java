package pt.technic.apps.minesfinder;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;


public class SignWindow extends JFrame {
	private JLabel signInTitle;
	private JLabel nameLabel;
	private JLabel passwordLabel;
	
	private JTextField nameText;
	private JTextField passwordText;
	private JPanel contentPanel;
	private JPanel btnsPanel;
	private JButton signInBtn;
	private JButton signUpBtn;
	private RecordController controller;
	
	private JLabel userNameLabel;
	public SignWindow(JLabel userNameLabel) {
		initComponent();
		controller = RecordController.getInstance();
		signInBtn.addActionListener(evt -> signInActionPerformed(evt));
		signUpBtn.addActionListener(evt -> signUpActionPerformed(evt));
		this.userNameLabel = userNameLabel;
		pack();
	}
	//TODO JLabel changeJLabel values
	private void initComponent() {

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setTitle(Constants.MINES_FINDER_TEXT.getMainTitle());
        setCursor(Constants.DEFAULT_CURSOR);
        setPreferredSize(new Dimension(600, 450));
        setResizable(false);
        
		signInTitle = new JLabel(Constants.SIGN_WINDOW_TEXT.getSignWindowTitle());
		signInTitle.setHorizontalAlignment(SwingConstants.CENTER);
		
		nameLabel = new JLabel(Constants.SIGN_WINDOW_TEXT.getNameText());
		passwordLabel = new JLabel(Constants.SIGN_WINDOW_TEXT.getPasswordText());
		
		nameText = new JTextField();
		passwordText = new JTextField();

		
		getContentPane().add(signInTitle, BorderLayout.PAGE_START);
		contentPanel = new JPanel();
		contentPanel.setLayout(new GridLayout(2, 0));
		contentPanel.add(nameLabel);
		contentPanel.add(nameText);
		contentPanel.add(passwordLabel);
		contentPanel.add(passwordText);
		
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
		signInBtn = new JButton(Constants.SIGN_WINDOW_TEXT.getSignInText());
		signUpBtn = new JButton(Constants.SIGN_WINDOW_TEXT.getSignUpText());
		btnsPanel = new JPanel(new GridLayout(2, 0));
		btnsPanel.add(signInBtn);
		btnsPanel.add(signUpBtn);
		getContentPane().add(btnsPanel, BorderLayout.PAGE_END);
	}
	//TODO
	private void signInActionPerformed(ActionEvent evt) {
		if(!checkHasSpace()) {
			User user = new User(nameText.getText(), passwordText.getText());
			if(controller.signIn(user)) {
				JOptionPane.showMessageDialog(null, Constants.SIGN_WINDOW_TEXT.getSignInSuccessMessageContent(), Constants.SIGN_WINDOW_TEXT.getSignInText(), JOptionPane.PLAIN_MESSAGE);
				userNameLabel.setText(user.getName());
				setVisible(false);
			}else {
				JOptionPane.showMessageDialog(null, Constants.SIGN_WINDOW_TEXT.getSignInFailedMessageContent(), Constants.SIGN_WINDOW_TEXT.getSignInFailedMessageTitle(), JOptionPane.PLAIN_MESSAGE);
				nameText.setText("");
				passwordText.setText("");
			}
		}
	}
	//TODO
	private void signUpActionPerformed(ActionEvent evt) {
		if(!checkHasSpace()) {
			User user = new User(nameText.getText(), passwordText.getText());
			if(controller.signUp(user)) {
				JOptionPane.showMessageDialog(null, Constants.SIGN_WINDOW_TEXT.getSignUpSuccessMessageContent(), Constants.SIGN_WINDOW_TEXT.getSignUpText(), JOptionPane.PLAIN_MESSAGE);
			}else {
				JOptionPane.showMessageDialog(null, Constants.SIGN_WINDOW_TEXT.getSignUpFailedMessageContent(), Constants.SIGN_WINDOW_TEXT.getSignUpFailedMessageTitle(), JOptionPane.PLAIN_MESSAGE);
				nameText.setText("");
				passwordText.setText("");
			}
		}
	}
	//TODO
	private boolean checkHasSpace() {
		if(nameText.getText().contains(" ") || passwordText.getText().contains(" ") || nameText.getText().isEmpty() || passwordText.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, Constants.SIGN_WINDOW_TEXT.getCheckHasSpaceMessageContent(), Constants.MINES_FINDER_TEXT.getWarningMessageTitle(), JOptionPane.WARNING_MESSAGE);
			return true;
		}else return false;
	}
}