package text;

public abstract class MinesFinderText {
	public static MinesFinderText[] subObj = { new EnglishMinesFinderText(), new KoreanMinesFinderText() };
	private String mainTitle;


	private String recordsText;
	private String[] levelText = new String[4];
	private String warningMessageTitle;

	// UItext of menubars for MinesFinder class
	private String menuBarText[] = new String[2];
	private String optionMenuText[] = new String[4];

	public String getMainTitle() {
		return mainTitle;
	}
	
	public String getRecordsText() {
		return recordsText;
	}

	public String[] getLevelText() {
		return levelText;
	}

	public String[] getMenuBarText() {
		return menuBarText;
	}

	public String[] getOptionMenuText() {
		return optionMenuText;
	}

	protected void setMainTitle(String mainTitle) {
		this.mainTitle = mainTitle;
	}

	protected void setRecordsText(String recordsText) {
		this.recordsText = recordsText;
	}

	protected void setLevelText(String[] levelText) {
		this.levelText = levelText;
	}

	protected void setMenuBarText(String[] menuBarText) {
		this.menuBarText = menuBarText;
	}

	protected void setOptionMenuText(String[] optionMenuText) {
		this.optionMenuText = optionMenuText;
	}

	protected void setWarningMessageTitle(String numMinesWarningMessageTitle) {
		this.warningMessageTitle = numMinesWarningMessageTitle;
	}

	public String getWarningMessageTitle() {
		return warningMessageTitle;
	}
}
