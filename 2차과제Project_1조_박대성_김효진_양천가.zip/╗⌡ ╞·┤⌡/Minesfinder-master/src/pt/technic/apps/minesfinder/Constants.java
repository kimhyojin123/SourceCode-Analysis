package pt.technic.apps.minesfinder;

import java.awt.*;
import java.io.File;

import text.CustomSettingWindowText;
import text.EnglishMinesFinderText;
import text.GameWindowText;
import text.KoreanMinesFinderText;
import text.MinesFinderText;
import text.SignWindowText;

public class Constants {
	
	
	public static final Font NOTO_SANS_FONT = new Font("Noto Sans", 0, 14);
	public static final Font UBUNTU_FONT = new Font("Ubuntu", 1, 24);
	public static final Cursor DEFAULT_CURSOR = new Cursor(Cursor.DEFAULT_CURSOR);
	public static final Dimension DEFAULT_DIMENSION = new Dimension(600, 450);
	public static final Color VIOLET = new Color(136, 135, 217);
	public static final String RESET_PLAYERNAME = "Player";
	public static final String RESET_PLAYCOUNT = "9999";
	
	public static MinesFinderText MINES_FINDER_TEXT;
	public static GameWindowText GAME_WINDOW_TEXT;
	public static CustomSettingWindowText CUSTOM_SETTING_WINDOW_TEXT;
	public static SignWindowText SIGN_WINDOW_TEXT;
	
	private static final String IMAGE_PATH = "/pt/technic/apps/minesfinder/resources/";
	private static final String EXTENSION = ".png";
	
	public static final String SOUND_RESOURCE = System.getProperty("user.dir") +"/src" + IMAGE_PATH + "bomb.wav";
	
	public static final String LEVEL_IMAGE_RESOURCE[] = { IMAGE_PATH + "easy" + EXTENSION, IMAGE_PATH + "medium" + EXTENSION, IMAGE_PATH + "hard" + EXTENSION };
	
	public static final String FILE_PATH = System.getProperty("user.home") + File.separator + ".minesfinder.records";
	
	
	public static void changeLanguage(String language) {
		int order = Language.toLanguage(language).ordinal();
		MINES_FINDER_TEXT = MinesFinderText.subObj[order];
		GAME_WINDOW_TEXT = GameWindowText.subObj[order];
		CUSTOM_SETTING_WINDOW_TEXT = CustomSettingWindowText.subObj[order];
		SIGN_WINDOW_TEXT = SignWindowText.subObj[order];
	}
	static {
		changeLanguage(Language.ENGLISH.toString());
	}
}
