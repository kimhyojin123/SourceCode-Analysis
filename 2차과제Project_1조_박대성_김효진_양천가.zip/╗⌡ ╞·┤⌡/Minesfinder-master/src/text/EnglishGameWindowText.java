package text;

public class EnglishGameWindowText extends GameWindowText {
	{
		 setGameTitle("Game");
		 setResetText("Reset");
		 setLostMessageContent("Oh, a mine broke");
		 setLostMessageTitle("Lost!");
		 setVictoryMessageContent("Congratulations. You managed to discover all the mines in ");
		 setVictoryMessageTitle("Victory!");
		
		 setSecond(" second");
		 setRestMinesText("Covered Mines : ");
	}
}
