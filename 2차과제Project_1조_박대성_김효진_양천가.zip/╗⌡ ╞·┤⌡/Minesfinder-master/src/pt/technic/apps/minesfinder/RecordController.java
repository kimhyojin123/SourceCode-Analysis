package pt.technic.apps.minesfinder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;


public class RecordController {
	private final int EASY = LevelAndCommand.EASY.ordinal();
	private final int MEDIUM = LevelAndCommand.MEDIUM.ordinal();
	private final int HARD = LevelAndCommand.HARD.ordinal();
	private User user;

	private RecordTable records[] = new RecordTable[3]; // 湲곕줉�젏�닔 ���옣�빐�넃�뒗 媛앹껜 -- Tables for Record
	private RecordTable globalRecords[][] = new RecordTable[3][3];
	private RecordTableListener tableListener;
	private DatabaseAccess dba;
	
	private RecordController() {
		tableListener = record -> recordUpdated(record);
		dba = new DatabaseAccess();
		
		readGameLocalRecords();
		if(records[0] == null) {
			for(int i = EASY; i <= HARD; i++) {
				records[i] = new RecordTable();
				records[i].addRecordTableListener(tableListener);
			}
		}
		if(globalRecords[0][0] == null) {
			for(int i = 0; i < globalRecords.length; i++) {
				for(int j = 0; j < globalRecords[i].length; j++) {
					globalRecords[i][j] = new RecordTable();
				}
			}
		}
		readGameGlobalRecords();
	};
	private static class Singleton{
		private static RecordController instance = new RecordController();
	}
	public static RecordController getInstance() {
		return Singleton.instance;
	}
	
	public RecordTable[] getRecords() {
		return records;
	}
	
    /*
     * 湲곕줉 蹂댁뿬二쇰뒗 硫붿꽌�뱶 -- Show Record for Game
     *		�뼺�뼺�뼺 
     */
    private void recordUpdated(RecordTable record) {
    	saveGameRecords();
    }
    /*
     * 		�뼰�뼰�뼰
     * 湲곕줉 蹂댁뿬二쇰뒗 硫붿꽌�뱶 -- Show Record for Game
     */
    private void saveGameRecords() {
    	saveGameLocalRecord();
        for(int i = 0; i < globalRecords.length; i++) {
        	for(int j = 0; j < globalRecords[i].length; j++) {
        		if(globalRecords[i][j].getName().equals(records[i].getName()) && globalRecords[i][j].getScore() == records[i].getScore()) {
        			break;
        		}
        	}
        }
        for(int i = 0; i < globalRecords.length; i++) {
        	int changeIndex = globalRecords[i].length;
        	for(int j = globalRecords[i].length-1; j >= 0; j--) {
        		if(records[i].getScore() < globalRecords[i][j].getScore()) {
        			changeIndex = j;
        		}
        	}
        	if(changeIndex < globalRecords[i].length) {
        		globalRecords[i][changeIndex].setName(records[i].getName());
        		globalRecords[i][changeIndex].setScore(records[i].getScore() );
        	}
        }
        dba.setData("delete from minesfinder.rank");
        String insertRankDataQuery = "insert into minesfinder.rank(name, score, level) values(?, ?, ?)";
        for(int i = 0; i < globalRecords.length; i++) {
        	for(int j = 0; j < globalRecords[i].length; j++) {
        		List<String> values = new ArrayList<String>();
        		values.add(globalRecords[i][j].getName());
        		values.add(String.valueOf(globalRecords[i][j].getScore()));
        		values.add(String.valueOf(i));
                dba.setData(insertRankDataQuery, values);
        	}
        }
        
    }
    private void saveGameLocalRecord() {
        ObjectOutputStream oos = null;
        try {
            File f = new File(Constants.FILE_PATH);
            oos = new ObjectOutputStream(new FileOutputStream(f));
            for(int i = EASY; i <= HARD; i++) {
            	oos.writeObject(records[i]);
            }
            oos.close();
        } catch (IOException ex) {
            Logger.getLogger(RecordController.class.getName()).log(Level.SEVERE, null,
                    ex);
        }
    }
    private void readGameLocalRecords() {
        ObjectInputStream ois = null;
        File f = new File(Constants.FILE_PATH);
        if (f.canRead()) {
            try {
                ois = new ObjectInputStream(new FileInputStream(f));
                for(int i = EASY; i <= HARD; i++) {
                	records[i] = (RecordTable) ois.readObject();
                	records[i].addRecordTableListener(tableListener);
                }
                ois.close();
            } catch (IOException | ClassNotFoundException ex) {
                Logger.getLogger(RecordController.class.getName()).log(Level.SEVERE,
                        null, ex);
            }
        }
    }

    private void readGameGlobalRecords() {
    	String getRankDataQuery = "select * from minesfinder.rank";
    	List<Map> list = dba.getData(getRankDataQuery);
    	int levelCount[] = {0, 0, 0};
    	for(int i = 0; i < list.size(); i++) {
    		Map row = list.get(i);
    		String name = row.get("name").toString();
    		long score = Long.parseLong(row.get("score").toString());
    		int level = Integer.parseInt(row.get("level").toString());
    		globalRecords[level][levelCount[level]].setName(name);
    		globalRecords[level][levelCount[level]].setScore(score);
    		levelCount[level]++;
    	}
    	for(int i = 0; i < globalRecords.length; i++) {
    		for(int j = 0; j < globalRecords[i].length; j++) {
    			int minIndex = j;
    			for(int k = j + 1; k < globalRecords[i].length; k++) {
    				if(globalRecords[i][minIndex].getScore() > globalRecords[i][k].getScore()) {
    					minIndex = k;
    				}
    			}
    			long tmpScore = globalRecords[i][minIndex].getScore();
    			String tmpName = globalRecords[i][minIndex].getName();
    			globalRecords[i][minIndex].setScore(globalRecords[i][j].getScore());
    			globalRecords[i][minIndex].setName(globalRecords[i][j].getName());
    			globalRecords[i][j].setScore(tmpScore);
    			globalRecords[i][j].setName(tmpName);
    		}
    	}
    }
    public boolean signIn(User user) {
    	String getUserDataQuery = "select * from minesfinder.user where name = ?";
    	List values = new ArrayList();
    	values.add(user.getName());
    	List<Map> result = dba.getData(getUserDataQuery, values);
    	if(result.size() > 0) {
    		Map userData = result.get(0);
        	user.setName(userData.get("name").toString());
        	user.setPassword(userData.get("password").toString());
        	user.setMoney(new GameMoney(Integer.parseInt(userData.get("money").toString())));
        	this.user = user;
        	return true;
    	}else {
    		return false;
    	}
    }
    public boolean signUp(User user) {
    	String getUserDataQuery = "select * from minesfinder.user where name = ?";
    	List values = new ArrayList();
    	values.add(user.getName());
    	if(dba.getData(getUserDataQuery , values).size() == 0) {
    		values.clear();
    		String setUserDataQuery = "insert into minesfinder.user(name, password, money) values(?, ?, ?)";
    		values.add(user.getName());
    		values.add(user.getPassword());
    		values.add(10);
    		return dba.setData(setUserDataQuery, values);
    	}else {
    		return false;
    	}
    }
	public String getName() {
		try {
			return user.getName();
		}catch(NullPointerException ne){
			return null;
		}

	}

	public void setName(String name) {
		if(user != null) {
			user.setName(name);
		}else {
			
		}
		if(name != null) {
			saveGameRecords();
		}
	}
	public GameMoney getMoney() {
		return user.getMoney();
	}
	
	public RecordTable[][] getGlobalRecords() {
		return globalRecords;
	}
	public void saveGameMoney() {
		String updateGameMoneyQuery = "update minesfinder.user set money = ? where name = ?";
		List values = new ArrayList();
		values.add(user.getMoney().getMoney());
		values.add(user.getName());
		dba.setData(updateGameMoneyQuery, values);
	}
    
}
