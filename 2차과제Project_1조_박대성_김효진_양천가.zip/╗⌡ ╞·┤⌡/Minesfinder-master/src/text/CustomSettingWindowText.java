package text;

public class CustomSettingWindowText {
	public static CustomSettingWindowText[] subObj = { new EnglishCustomSettingWindowText(), new KoreanCustomSettingWindowText()};
	//UIText for CustomSettingWindow
	private String customSettingTitle;
	private String widthText;
	private String heightText;
	private String numMinesText;
	private String submitText;
	private String muchNumMinesWarningMessageContent;
	private String zeroNumMinesWarningMessageContent;
	protected void setCustomSettingTitle(String customSettingTitle) {
		this.customSettingTitle = customSettingTitle;
	}
	protected void setWidthText(String widthText) {
		this.widthText = widthText;
	}
	protected void setHeightText(String heightText) {
		this.heightText = heightText;
	}
	protected void setNumMinesText(String numMinesText) {
		this.numMinesText = numMinesText;
	}
	protected void setSubmitText(String submitText) {
		this.submitText = submitText;
	}
	protected void setMuchNumMinesWarningMessageContent(String muchNumMinesWarningMessageContent) {
		this.muchNumMinesWarningMessageContent = muchNumMinesWarningMessageContent;
	}
	protected void setZeroNumMinesWarningMessageContent(String zeroNumMinesWarningMessageContent) {
		this.zeroNumMinesWarningMessageContent = zeroNumMinesWarningMessageContent;
	}
	public String getCustomSettingTitle() {
		return customSettingTitle;
	}
	public String getWidthText() {
		return widthText;
	}
	public String getHeightText() {
		return heightText;
	}
	public String getNumMinesText() {
		return numMinesText;
	}
	public String getSubmitText() {
		return submitText;
	}
	public String getMuchNumMinesWarningMessageContent() {
		return muchNumMinesWarningMessageContent;
	}
	public String getZeroNumMinesWarningMessageContent() {
		return zeroNumMinesWarningMessageContent;
	}
	
}
