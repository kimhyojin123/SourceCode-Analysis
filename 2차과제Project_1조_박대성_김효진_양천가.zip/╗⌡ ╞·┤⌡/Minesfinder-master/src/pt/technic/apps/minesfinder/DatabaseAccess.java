package pt.technic.apps.minesfinder;

import java.util.*;
import java.sql.*;

public class DatabaseAccess {
	private final String JDBC_DRIVER  = "com.mysql.cj.jdbc.Driver";
	private final String DB_NAME = "minesfinder";
	private final String DB_HOSTNAME = "localhost";
	private final String DB_PORT = "3306";
	private final String DB_URL = "jdbc:mysql://"+ DB_HOSTNAME +":" + DB_PORT + "/" + DB_NAME + "?serverTimezone=UTC";
	private final String DB_USER = "root";
	private final String DB_PASSWORD = "dPdms7942*";
	private Connection conn;
	private PreparedStatement pstmt;
	
	public DatabaseAccess() {
		try {
			Class.forName(JDBC_DRIVER);
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	public boolean setData(String sqlQuery) {
		return setData(sqlQuery, new ArrayList());
	}
	public boolean setData(String sqlQuery, List values) {
		int numberOfQm = countQm(sqlQuery);
		if(numberOfQm != values.size()) {
			System.out.println("물음표 갯수랑 속성값 갯수가 달라");
			return false;
		}
		try {
			conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
			pstmt = conn.prepareStatement(sqlQuery);
			for(int count = 0; count < numberOfQm ; count++) {
				pstmt.setString(count + 1, values.get(count).toString());
			}
			pstmt.executeUpdate();
		}catch(SQLException SQLe) {
			System.out.println(SQLe);
			return false;
		}finally {
			try {
				pstmt.clearParameters();
				pstmt.close();
				conn.close();
			}catch(SQLException SQLe) {
				System.out.println(SQLe);
				return false;
			}
		}
		return true;
	}	
	
	public List <Map> getData(String sqlQuery){
		List<Map> values = new ArrayList();
		return getData(sqlQuery,values);
	}
	public List <Map> getData(String sqlQuery, List values){
		List<Map> result = new ArrayList<Map>();
		int numberOfQm = countQm(sqlQuery);
		if(numberOfQm != values.size()) {
			System.out.println("물음표 갯수랑 속성값 갯수가 달라");
			return null;
		}
		try {
			conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
			pstmt = conn.prepareStatement(sqlQuery);
			for(int count = 0; count < numberOfQm; count++) {
				pstmt.setString(count + 1,  values.get(count).toString());
			}
			ResultSet rs = pstmt.executeQuery();

			while(rs.next()) {
				ResultSetMetaData metadata = rs.getMetaData();
				Map<String, Object> index = new HashMap<String,Object>();
				for(int count = 0; count < metadata.getColumnCount(); count++) {
					index.put(metadata.getColumnLabel(count+1).toString(), rs.getObject(metadata.getColumnLabel(count+1).toString()));
				}
				result.add(index);
			}
		}catch(SQLException SQLe) {
			System.out.println(SQLe);
			return null;
		}finally {
			try{
				pstmt.clearParameters();
				pstmt.close();
				conn.close();
			}catch(SQLException SQLe) {
				System.out.println(SQLe);
				return null;
			}
		}
		return result;
	}
	private int countQm(String clone) {
		int numberOfQm = 0;
		int length = clone.length();
		for(int count = 0; count < length; count++) 
			if(clone.charAt(count) == '?') 
				numberOfQm++;
		return numberOfQm;
	}
}
